from netmiko import ConnectHandler

ip_address = input("IP:  ")
felhasznalo = input("Felhasználónév: ")
jelszo = input("Jelszó: ")
parancs = input("Adja meg a lekérdezni kívánt parancsot: ")

device = {
    'device_type': 'cisco_ios',
    'ip': ip_address,
    'username': felhasznalo,
    'password': jelszo,
}

try:
    net_connect = ConnectHandler(**device)
    print(f"Csatlakozás sikeres! ({ip_address})")

    output = net_connect.send_command(parancs)

    with open(f"{ip_address}_{parancs}_log.txt", "w") as f:
        f.write(output)
    print(f"Kimenet naplózva! ({ip_address}_{parancs}_log.txt)")

    net_connect.disconnect()

except Exception as e:
    print(f"Csatlakozási hiba! ({ip_address}): {e}")

input("Nyomj Entert a kilépéshez!")
